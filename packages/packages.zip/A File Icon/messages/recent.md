# A File Icon 3.2.2

New release!

Please see `Tools → Packages → A File Icon → Changelog` for more info about 
the release.

***

Please reinstall package if you have some problems with upgrade.
Such issues will be fixed with the 4.0.0 version.
Finally I have some free time to continue work on it.
