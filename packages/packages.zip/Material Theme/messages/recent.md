#### Material Theme for Sublime Text 3

## Version 4.1.5

📣 **BUG FIXES**:
* Fix theme not activating after installation ([#1230](https://github.com/equinusocio/material-theme/issues/1230)) ([1e8ffa5](https://github.com/equinusocio/material-theme/commit/1e8ffa5))

** Check the official changelog (https://github.com/equinusocio/material-theme/blob/master/CHANGELOG.md) **
