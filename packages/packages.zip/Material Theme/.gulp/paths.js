import infos from '../package.json';

const paths = {
  'src': './sources',
  'utils': './utils',
  'schemes': './schemes',
  'widgets': './widgets',
  'extras': './extras'
};

export default paths;
